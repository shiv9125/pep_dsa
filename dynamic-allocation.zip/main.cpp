/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
using namespace std;

int main() 
{
    // dynamically allocating an integer memory block
    int* ptr = new int;

    // storing a value at the memory pointed by ptr
    *ptr = 10;
    int *arr=new int[10];

    cout << "Value at memory pointed by ptr= " << *ptr;
}