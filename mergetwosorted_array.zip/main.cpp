/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include<bits/stdc++.h>
#include <iostream>

using namespace std;
void mergesortarray(int a[], int b[], int m , int n){
    int c[m+n];
    for(int i=0; i<m; i++){
        c[i]=a[i];
    }
    for(int j=0; j<n; j++){
        c[m+j]=b[j];
    }
    sort(c,c+m+n);
    for(int i=0; i<m+n; i++){
        cout<<c[i]<<" ";
    }
}

int main()
{
    int a[]={10,15,20,40,50};
    int b[]={8,9,11,11,12};
    int m=5;
    int n=5;
    mergesortarray(a,b,m,n);

    return 0;
}
