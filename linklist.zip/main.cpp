/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
struct node{
    int data;
    node* next;
    node(int x){
        data=x;
        next=NULL;
    }
    
};

void printlist(node* head){
    while(head!=NULL){
         cout<<head->data<<endl;
         head=head->next;
        }
    }


int main()
{
    node*head=new node(10);
    node*second=new node(20);
    node*third=new node(30);
    head->next=second;
    second->next=third;
    third->next=NULL;
    printlist(head);
    
    return 0;
}

