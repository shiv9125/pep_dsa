/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
bool bs(int arr[], int low, int high, int key){
    
    if(low>high){
    return false;
    }
    
    int mid=(low+high)/2;
    
    if(arr[mid]==key){
    return true;
    }
    else if(arr[mid]>key)
    {
    return bs(arr,low,mid-1,key);
    }
    else
    {
    return bs(arr,mid+1,high,key);
    } 
  
}

int main()
{
   int arr[]={2,3,4,5,6,7};
   int size=6;
   int key=7;
   cout<<bs(arr,0,size-1,key);

    return 0;
}
