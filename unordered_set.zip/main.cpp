#include <bits/stdc++.h> 
using namespace std; 

int main(){
    
    unordered_set <int> s;
    s.insert(10);
    s.insert(5);
    s.insert(15);
    s.insert(20);
    for(auto x: s)//first way to print
        cout<<x<<" ";
        
    cout<<endl;
    for(auto it=s.begin();it!=s.end();it++)//second way to print
        cout<<*it<<" ";
    cout<<endl;
    cout<<s.size()<<endl;
    s.clear();
    cout<<s.size()<<endl;
        
    return 0;
}