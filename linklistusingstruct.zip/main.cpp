/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
struct node{
    int data;
    node*next;
    node(int x){
        data=x;
        next=NULL;
    }
};
int main()
{
    node*head=new node(10);
    node*temp1=new node(20);
    node*temp2=new node(30);
    head->next=temp1;
    temp1->next=temp2;
    cout<<head->data<<"-->"<<temp1->data<<"-->"<<temp2->data;

    return 0;
}
