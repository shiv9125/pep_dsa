/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
int getsum(int arr[], int size){
    if(size==1)
    return arr[0];
    if(size==0)
    return 0;
    
    int sum=arr[0];
    sum=sum+getsum(arr+1,size-1);
    return sum;
}

int main()
{
   int arr[]={2,10,4,5,6};
   int size=5;
   cout<<getsum(arr,size);
    return 0;
}
