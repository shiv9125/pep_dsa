/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
int flornumber(int arr[], int n,int target){
    int low=0;
    int high=n-1;
    int flor=-1;
    while(low<=high){
        int mid=(low+high)/2;
        if(arr[mid]==target){
            return mid;
        }
        else if(arr[mid]<target){
            low=mid+1;
            flor=mid;
        }
        else{
            high=mid-1;
        }
    }
    return flor;
    
}

int main()
{
    int arr[]={2,4,8,16,18,20};
    int n=sizeof(arr)/sizeof(int);
    int target=19;
    cout<<flornumber(arr,n,target);

    return 0;
}

