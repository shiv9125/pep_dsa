/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
int ceelnumber(int arr[], int n,int target){
    int low=0;
    int high=n-1;
    int ceel=-1;
    while(low<=high){
        int mid=(low+high)/2;
        if(arr[mid]==target){
            return mid;
        }
        else if(arr[mid]<target){
            low=mid+1;
        }
        else{
            high=mid-1;
            ceel=mid;
        }
    }
    return ceel;
    
}

int main()
{
    int arr[]={2,4,8,16,18,20};
    int n=sizeof(arr)/sizeof(int);
    int target=15;
    cout<<ceelnumber(arr,n,target);

    return 0;
}
